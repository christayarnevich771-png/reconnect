# Recoverly — Social Account Appeal & Recovery Website

A responsive static website for a legitimate social-media account appeal/recovery assistance service.

## Included
- Responsive homepage
- Facebook / Instagram / TikTok service cards
- How-it-works section
- Account assistance request form
- Customer feedback placeholders
- FAQ
- Contact/footer
- Mobile navigation
- Clean black/white/red visual system

## Run
No build step is required.

1. Extract the ZIP.
2. Open `index.html` in a browser.

For production, connect the request form to your own backend/email/CRM and replace:
- `hello@example.com`
- placeholder reviews
- company name/logo
- contact details

## Important
The site intentionally does not claim guaranteed unbans, platform employee access, or affiliation with Meta/TikTok. Do not collect passwords, OTPs, recovery codes, or payment PINs.
