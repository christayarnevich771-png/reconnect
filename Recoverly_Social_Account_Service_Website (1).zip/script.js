const menuBtn=document.getElementById("menuBtn"),nav=document.getElementById("navLinks");
menuBtn.addEventListener("click",()=>nav.classList.toggle("open"));
document.querySelectorAll("#navLinks a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));
document.querySelectorAll("[data-platform]").forEach(link=>link.addEventListener("click",()=>{document.getElementById("platform").value=link.dataset.platform;}));
document.getElementById("requestForm").addEventListener("submit",e=>{
 e.preventDefault();
 const msg=document.getElementById("formMsg");
 msg.textContent="Request prepared successfully. Connect this form to your email/CRM/backend before launch.";
 msg.style.color="#16834b";
});
